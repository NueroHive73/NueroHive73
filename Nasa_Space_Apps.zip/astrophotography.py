def get_star_info(location):
    # Placeholder for actual star-tracking logic using APIs like Starlink
    return "Orion, Sirius, Betelgeuse"
