from textblob import TextBlob

def analyze_emotion(user_input):
    analysis = TextBlob(user_input)
    
    if analysis.sentiment.polarity > 0:
        return "Positive"
    elif analysis.sentiment.polarity < 0:
        return "Negative"
    else:
        return "Neutral"
