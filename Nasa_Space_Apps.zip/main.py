from weather_api import get_weather
from emotion_detection import analyze_emotion
from astrophotography import get_star_info

def handle_weather():
    location = input("Please share your location: ")
    weather = get_weather(location)
    print(f"The current weather in {location} is: {weather}")

def handle_emotion():
    user_input = input("How are you feeling today? ")
    emotion = analyze_emotion(user_input)
    print(f"Based on your input, you're feeling: {emotion}")

def handle_astrophotography():
    location = input("Please share your location for star tracking: ")
    stars = get_star_info(location)
    print(f"Visible stars in your sky: {stars}")

def welcome_to_bootcamp():
    name = input("What's your name? ")
    age = input(f"Nice to meet you, {name}. How old are you? ")
    print(f"Welcome to the NASA Space Apps Challenge Bootcamp, {name}!")

def main():
    print("Welcome to Cosmo, your AI assistant!")
    print("1. Weather Detection\n2. Emotion Detection\n3. Astrophotography\n4. NASA Bootcamp")
    choice = input("Choose an option (1-4): ")

    if choice == '1':
        handle_weather()
    elif choice == '2':
        handle_emotion()
    elif choice == '3':
        handle_astrophotography()
    elif choice == '4':
        welcome_to_bootcamp()
    else:
        print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
