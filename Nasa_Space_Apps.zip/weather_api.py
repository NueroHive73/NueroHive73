import requests

def get_weather(location):
    # Replace with your actual API key
    api_key = "your_weather_api_key"
    url = f"http://api.weatherapi.com/v1/current.json?key={api_key}&q={location}"
    
    response = requests.get(url)
    data = response.json()
    
    if "current" in data:
        return f"{data['current']['condition']['text']}, {data['current']['temp_c']}°C"
    else:
        return "Unable to retrieve weather data."
